<?php session_start(); ?>
<html>
	<head>
		<title>OFRECER HABITACIÓN</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>
	<div class="container">
	<div class="row">
	<div class="col-md-6">
	<form role="form" name="Agregar Habitacion" action="php/ofrecer.php" method="post">
		<div class="form-group">
 		 <label for="titulo">Titulo</label>
 		 <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Titulo">
 	 </div>
	 <div class="form-group">
		<label for="dimensiones">Dimensiones</label>
		<input type="text" class="form-control" id="dimensiones" name="dimensiones" placeholder="Dimensiones de la Habitacion">
	</div>

	<div class="form-group">
	<label for="ubicacion">Ubicación</label>
	<input type="text" class="form-control" id="ubicacion" name="ubicacion" placeholder="Ubicacion">
</div>

		<div class="form-group">
			<label for="descripcion">Descripción</label>
			<input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion">
		</div>
		<div class="form-group">
			<label for="precio">Precio</label>
			<input type="number"step="0.1" class="form-control" id="precio" name="precio" >
		</div>



		<button type="submit" class="btn btn-default">Agregar HABITACIÓN</button>
		</form>
	</div>
	</div>
	</div>
			<script src="js/valida_habitacion.js"></script>
	</body>
</html>
