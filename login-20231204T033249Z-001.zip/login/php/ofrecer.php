<?php

if(!empty($_POST)){
	if(isset($_POST["titulo"]) &&isset($_POST["dimensiones"]) &&isset($_POST["ubicacion"]) &&isset($_POST["descripcion"]) &&isset($_POST["precio"])){
		if($_POST["titulo"]!=""&& $_POST["dimensiones"]!=""&&$_POST["ubicacion"]!=""&&$_POST["descripcion"]!=""&&$_POST["precio"]){
			include "conexion.php";

			$found=false;
			$sql12= "select * from habitacion where titulo=\"$_POST[titulo]\"";
			$query = $con->query($sql12);
			while ($r=$query->fetch_array()) {
				$found=true;
				break;
			}
			if($found){
				print "<script>alert(\"Habitacion  ya esta registrada.\");window.location='../ofrecer.php';</script>";
			}
			$sqlhab = "insert into habitacion(titulo,dimensiones,ubicacion,descripcion,precio,created_ath) value (\"$_POST[titulo]\",\"$_POST[dimensiones]\",\"$_POST[ubicacion]\",\"$_POST[descripcion]\",\"$_POST[precio]\",NOW())";
			$query = $con->query($sqlhab);
			if($query!=null){
				print "<script>alert(\"HABITACIÓN CREADA\");window.location='../adquirir.php';</script>";
			}
		}
	}
}



?>
