<?php
$host="localhost";
$user="root";
$password="";
$db="myapp";
$con = new mysqli($host,$user,$password,$db);

?>