with(document.registro){
	onsubmit = function(e){
		e.preventDefault();
		ok = true;
		if(ok && titulo.value==""){
			ok=false;
			alert("Debe escribir un titulo");
			titulo.focus();
		}
		if(ok &&dimensiones.value==""){
			ok=false;
			alert("Debe escribir las dimensiones de la habitacion ");
			dimensiones.focus();
		}
		if(ok && descripcion.value==""){
			ok=false;
			alert("Debe escribir una breve descripcion de la habitacion");
			descripcion.focus();
		}
		if(ok && precio.value==""){
			ok=false;
			alert("Debe escribir el precio");
			precio.focus();
		}
		

		if(ok){ submit(); }
	}
}
