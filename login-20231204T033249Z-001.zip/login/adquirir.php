<?php session_start(); ?>
<html>
	<head>
		<title>ADQUIRIR HABITACIÓN</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>

</html>
