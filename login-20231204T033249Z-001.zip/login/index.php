<?php
session_start();
?>
<html>
	<head>
		<title>A DONDE ALQUILAR</title>
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	</head>
	<body>
	<?php include "php/navbar.php"; ?>
	<div class="container">
	<div class="row">
	<div class="col-md-12">
			<h2>A DONDE ALQUILAR.com</h2>
			<p class="lead">Espacio donde podras poner en alquiler tu habitación y tambien alquilar las de otras personas</p>
			<p>Les presentamos <b>a donde alquilar.com</b> un sistema de alquiler de habitaciones</p>
			<p>Opciones:</p>
			<ol>
				<li>Registrarse</li>
				<li>Rellenar datos personales</li>
				<li>Subir caracteristicas de la habitación</li>
				<li>Subir habitación</li>
				<li>Alquilar habitación</li>
			</ol>
			<br>
			<ul type="none">
			<li><i class="glyphicon glyphicon-ok"></i> Facil y sencillo</li>
			<li><i class="glyphicon glyphicon-ok"></i> Seguro y veloz</li>
			</ul>

	</div>
	</div>
	</div>
	</body>
</html>
